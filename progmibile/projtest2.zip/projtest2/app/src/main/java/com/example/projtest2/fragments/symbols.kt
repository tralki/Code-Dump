package com.example.projtest2.fragments

data class symbols (
    val symba: String
)