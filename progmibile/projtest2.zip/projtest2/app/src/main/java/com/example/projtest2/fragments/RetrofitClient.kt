package com.example.projtest2.fragments

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitClient {
    val api: news by lazy {
        Retrofit.Builder()
            .baseUrl("https://tuxdroid.pythonanywhere.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(news::class.java)
    }
    val apis: symbSummary by lazy {
        Retrofit.Builder()
            .baseUrl("https://tuxdroid.pythonanywhere.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(symbSummary::class.java)
    }
}