package com.example.projtest2.fragments

import android.view.LayoutInflater
import retrofit2.http.Url
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import com.squareup.picasso.Picasso
import android.widget.ImageView

import android.widget.TextClock
import android.widget.TextView
import androidx.annotation.NonNull
import androidx.recyclerview.widget.RecyclerView
import com.example.projtest2.R

internal class CreateAdapter(
    var todos: List<symbSummary>
) : RecyclerView.Adapter<CreateAdapter.Todoviewholder>() {

    internal class Todoviewholder(itemView: View) : RecyclerView.ViewHolder(itemView){
        val titulo: TextView = itemView.findViewById(R.id.logo)
        val descricao: TextView = itemView.findViewById(R.id.precentage)
        val data: TextView = itemView.findViewById(R.id.price)
        val image: ImageView = itemView.findViewById(R.id.logo)
        val check: CheckBox = itemView.findViewById(R.id.checkBox)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): CreateAdapter.Todoviewholder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.reciclecreate, parent, false)
        return CreateAdapter.Todoviewholder(view)
    }
    fun updateData(newSummaryList: List<symbSummary>) {
        todos = newSummaryList
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: CreateAdapter.Todoviewholder, position: Int) {
        val currentSummary = todos[position]

        holder.titulo.text = currentSummary.symbol
        holder.data.text = currentSummary.current_price.toString()
        holder.descricao.text = currentSummary.change_percent.toString()
        holder.check.isChecked = currentSummary.checked
        Picasso.get().load(currentSummary.logo_url).into(holder.image)
    }

    override fun getItemCount(): Int {
        return todos.size
    }
}
